import { Component } from '@angular/core';

@Component({
  selector: 'app-user-device-mapping',
  templateUrl: './user-device-mapping.component.html',
  styleUrls: ['./user-device-mapping.component.scss']
})
export class UserDeviceMappingComponent {

}

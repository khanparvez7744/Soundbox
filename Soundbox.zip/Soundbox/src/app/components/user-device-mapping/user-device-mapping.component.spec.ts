import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDeviceMappingComponent } from './user-device-mapping.component';

describe('UserDeviceMappingComponent', () => {
  let component: UserDeviceMappingComponent;
  let fixture: ComponentFixture<UserDeviceMappingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserDeviceMappingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserDeviceMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

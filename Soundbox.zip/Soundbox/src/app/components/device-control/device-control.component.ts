import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-device-control',
  templateUrl: './device-control.component.html',
  styleUrls: ['./device-control.component.scss'],
})

export class DeviceControlComponent {
  public empData: any;
  public temp: Object = false;
  constructor(private http: HttpClient) { }
  ngOnInit(): void {
    this.http.get('https://jsonplaceholder.typicode.com/posts').subscribe((resp) => {
      this.empData = resp;
      this.temp = true;
    });
  }
}

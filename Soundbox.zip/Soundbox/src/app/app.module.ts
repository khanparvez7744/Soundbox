import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { ViewUserComponent } from './components/view-user/view-user.component';
import { UserDeviceMappingComponent } from './components/user-device-mapping/user-device-mapping.component';
import { AddDeviceComponent } from './components/add-device/add-device.component';
import { ViewDeviceComponent } from './components/view-device/view-device.component';
import { DeviceControlComponent } from './components/device-control/device-control.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { DataTablesModule } from 'angular-datatables';
import { CommonModule } from '@angular/common'; 
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddUserComponent,
    ViewUserComponent,
    UserDeviceMappingComponent,
    AddDeviceComponent,
    ViewDeviceComponent,
    DeviceControlComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, DataTablesModule,CommonModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}

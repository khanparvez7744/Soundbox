import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DeviceControlComponent } from './components/device-control/device-control.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { AddDeviceComponent } from './components/add-device/add-device.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'device-control', component: DeviceControlComponent },
  { path: 'add-user', component: AddUserComponent },
  { path: 'add-device', component: AddDeviceComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
